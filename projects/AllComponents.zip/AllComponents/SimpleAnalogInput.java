import com.pi4j.io.gpio.*;
/**
 * The class SimpleAnalog will use the fact that the time a capacitor takes to reach a logical state of high
 * is proportional to the resitance connected to it. So, this class first completely discharge a capacitor,
 * then allows it to charge again and estimates the time it took to do so: this time is an estimation of the 
 * resistance linked to the capacitor.
 * 
 * @author Fabio Hedayioglu 
 * @version 1.0
 */
public class SimpleAnalogInput
{
    private GpioPinDigital pin; //the pin to be used.
    
    private int pinNumber; //the pin number.
    
    //An array which maps the GPIO pin numbers to integers
    private static final Pin[] pinMap = new Pin[] {RaspiPin.GPIO_00, RaspiPin.GPIO_01, RaspiPin.GPIO_02, RaspiPin.GPIO_03, RaspiPin.GPIO_04, 
        RaspiPin.GPIO_05, RaspiPin.GPIO_06, RaspiPin.GPIO_07, RaspiPin.GPIO_08, RaspiPin.GPIO_09, RaspiPin.GPIO_10, 
        RaspiPin.GPIO_11, RaspiPin.GPIO_12, RaspiPin.GPIO_13, RaspiPin.GPIO_14, RaspiPin.GPIO_15, RaspiPin.GPIO_16, 
        RaspiPin.GPIO_17, RaspiPin.GPIO_18, RaspiPin.GPIO_19, RaspiPin.GPIO_20};

    GpioController gpio; //Needed to change the GPIO mode (input or output).
    /**
     * Creates a SimpleAnalogInput in a given GPIO.
     */
    public SimpleAnalogInput(int p)
    {
        gpio = GpioFactory.getInstance();
        pinNumber = p;
        pin = gpio.provisionDigitalOutputPin(pinMap[p], PinState.LOW);
    }
    
    /**
     * Reads the analog integer value.
     * @return an integer with the estimated value.
     */
    public int read()
    {
        pin.unexport();
        pin = gpio.provisionDigitalOutputPin(pinMap[pinNumber], PinState.LOW);
        int readValue;
        try {
            Thread.sleep(200); //wait a bit, so the capacitor can fully discharge.
        } catch (Exception e) {
        }
        pin.unexport();
        //now we set the pin to input.
        pin = gpio.provisionDigitalInputPin(pinMap[pinNumber], PinPullResistance.PULL_UP);
        readValue = 0;
        while ( pin.isLow()){
            //the capacitor will start to charge. The higher the resistance, the slower it will discharge.
            readValue++;
        }
        //the time the capacitor takes to charge and reach the high state (pi.isLow() == false) is proportional
        //to the resistance we want to measure.
        return readValue;
    }
}
