import com.pi4j.wiringpi.*;
/**
 * This class represents a PWM LED connected to the Raspberry pi on a given pin (default pin 6)
 * 
 * Connect the physical LED to a GND pin and to a GPIO pin.
 * 
 * 
 * @author Fabio Hedayioglu 
 * @author Ian Utting
 * @version 1.0
 * 
 */
public class AdjustableLED
{
    //The LED brightness level
    private int value;
    //The Pin number
    private static int PinNumber = 6;

    /**
     * Creates the Adjustable LED.
     * 
     */
    public AdjustableLED()
    {
        this(PinNumber);
    }
    
    /**
     * Creates the Adjustable LED in a given pin number.
     * 
     */
    public AdjustableLED(int pin)
    {
        Gpio.wiringPiSetup();
        //Sets the PinNumber pin to be a PWM pin, with values changing from 0 to 100
        SoftPwm.softPwmCreate(pin,0,100);
        value = 0;
        //Sets the LED to 0 brightness
        SoftPwm.softPwmWrite(pin, value);
    }
    
    
    
    /**
     * Set the LED value, valid values are integers from 0 to 100, inclusive.
     * 
     */
    public void setValue(int desiredValue)
    {
        //checks if the desired value is valid. if so, proceed.
        if (desiredValue >= 0 && desiredValue <= 100){
            //update the local value.
            value = desiredValue;
            //write white the desired value to the pin.
            SoftPwm.softPwmWrite(PinNumber, value);
        }
    }
    
    /**
     * Returns the current value of the LED.
     * @return integer from 0 to 100 with the LED current value.
     * 
     */
    public int getValue()
    {
        return value;
    }
}
