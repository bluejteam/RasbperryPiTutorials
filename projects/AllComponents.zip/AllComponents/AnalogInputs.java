import com.pi4j.wiringpi.Spi;

/**
 * The class represents the CMP3008, a chip that provides analog input ports to
 * the Raspberry Pi.
 *
 * @author Fabio Hedayioglu
 * @version 1.0
 */
public class AnalogInputs 
{

    /**
     * Constructor for objects of class MCP3008
     * 
     */
    public AnalogInputs() 
    {
        //initialize the SPI system and prepare the MCP3008 chip.
        if (Spi.wiringPiSPISetup(0, 500000) <= -1) { // 500Khz is the minimun frequency to operate the MCP3008.
            System.out.println(" ==>> SPI SETUP FAILED");
        }
    }
    
    
    /**
     * Read the input from a given channel.
     *
     * @param port number 
     * @return the value read by that port. It ranges from 0 to 1023
     */
    public int readChannel(int port) 
    {
        byte[] command = new byte[3];//in order to read the input, we first need to send a command, composed by 3 bytes.
        int value;
        command[0] = 1;//the first byte is the number 1.
        command[1] = (byte) (8 + port << 4); //the second byte has the port number.
        command[2] = 0; //the third byte is ignored
        Spi.wiringPiSPIDataRW(0, command, 3); //send the command to the MCP3008. The answer is written back to the same byte array.
        //put the value together: each byte has 8 bits, and the MCP3008 has 
        //10 bits resolution.: 3 bits on the command[1] and 8 in command[2]
        value =  ((command[1] & 3) << 8) + (command[2] & 0xff);
        return value;
    }
}
