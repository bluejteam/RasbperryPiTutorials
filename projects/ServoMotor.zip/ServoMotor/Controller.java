import java.util.Random;
/**
 *A controller for a servo motor at GPIO pin 1 using software Pulse Width Modulation (Soft PWD).
 *
 * This class controls the servo motor programatically.
 * 
 * Class used for BlueJ on Raspberry Pi tutorial.
 */
public class Controller
{
    // the servo motor
    private ServoMotor servo;

    /**
     * Constructor for objects of class Controller
     */
    public Controller()
    {
        // initialise the servo motor at the default gpio pin.
        servo = new ServoMotor();
        
    }
    
    /**
     * Move the Servo motor to the right by one position.
     * (Exercise 4.1)
     * 
     */
    public void moveRight()
    {
        int position = servo.getPosition();
        position = position + 1;
        servo.setPosition(position);
    }
    
    /**
     * Move the Servo motor to the left by one position.
     * (Exercise 4.2)
     * 
     */
    public void moveLeft()
    {
        //put your code here.
    }
    
    /**
     * Move the Servo motor to a given position.
     * @param The position from 0 to 20 where the servo motor should move to.
     * (Exercise 4.3)
     * 
     */
    public void moveTo(int position)
    {
        //put your code here.
    }
        
    /**
     * Eight ball game: Select a random number (accordingly to the number of messages in your 
     * eight ball sheet, found in the page) and move the motor to that position.
     * (Exercise 4.4)
     * 
     */
    public void eightBall()
    {
        //put your code here.
    }

    /**
     * Generates a random value from 0 to 5, ask the user to guess the value.
     * If the value entered by the user is lower than the one generated, wiggle the motor to the left.
     * If the value entered by the user is higher than the one generated, wiggle to the right.
     * @param number of guesses available to the user.
     * (Exercise 4.5)
     * 
     */
    public void guessGame(int numberOfGuesses)
    {
        //put your code here.
    }

    
   /*
    *  You don't need to change the methods below this point.
    *  They are just to help you with the examples on the web page.
    */
   
   /**
     * Cause the program to sleep for a short time.
     * @param milisec the number of milliseconds to sleep.
     * 
     */
    public void sleepMillisec(int millisec)
    {
        try
        {
            Thread.sleep(millisec);
        }
        catch ( InterruptedException e)
        {
        }
    }
    
    /**
     * Generates a random number from 0 to max.
     * @return the generated random number.
     * 
     */
    public int generateRandomNumber(int max)
    {
        Random random = new Random();
        return random.nextInt(max + 1);
    }
}
