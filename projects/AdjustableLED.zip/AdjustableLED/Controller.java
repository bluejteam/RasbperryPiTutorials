import java.net.*;
import java.io.*;

/**
 * A controller for an LED at pin 6 using software Pulse Width Modulation (Soft PWD).
 * 
 * This class controls the PWM LED programatically.
 * 
 * Class used for BlueJ on Raspberry Pi tutorial.
 * 
 */
public class Controller
{
    // The Adjustable LED
    private AdjustableLED adjLed; 

    /**
     * Constructor for objects of class Controller.
     */
    public Controller()
    {
        // initialise instance variables
        adjLed = new AdjustableLED(6);
    }

    /**
     * This method should set the LED to full brightness.
     * (Exercise 3.2)
     * 
     */
    public void setFullBrightness()
    {
        adjLed.setValue(100);
    }
    
    /**
     * This method should set the led output to zero.
     * (Exercise 3.2)
     * 
     */
    public void turnLEDOff()
    {
        adjLed.setValue(0);
    }
    
    
    /**
     * Dimm LED from full brightness to zero.
     * (Exercise 3.3)
     * 
     */
    public void dimmToZero()
    {
        //put your code here
    }
    
    /**
     * Light the LED gradually: from zero to full brightness smoothly.
     * (Exercise 3.4)
     * 
     */
    public void smoothLighthenUp()
    {
        //put your code here
    }
    
    /**
     * Light the LED accordingly to the number we receive from the internet.
     * (Exercise 3.5)
     * 
     */
    public void internetLight()
    {
        //put your code here.
    }
    
    /*
    *  You don't need to change the methods below this point.
    *  They are just to help you with the examples on the web page.
    */
    
    /**
     * Wait for a number of milliseconds
     * @param milisec the number of milliseconds to wait.
     */
    public void sleepMillisec(int millisec)
    {
        try
        {
            Thread.sleep(millisec);
        }
        catch ( InterruptedException e)
        {
        }
    }
    

    public String readFromUrl(String urlString) 
    {
        StringBuilder receivedData = new StringBuilder();
        try{

            URL userUrl = new URL(urlString);
            BufferedReader in = new BufferedReader(
            new InputStreamReader(userUrl.openStream()));
            
            String inputLine;
            if ((inputLine = in.readLine()) != null) {
                receivedData.append(inputLine);
            }
            while ((inputLine = in.readLine()) != null)
                receivedData.append("\n"+inputLine);
            in.close();
            
        } catch (Exception e) {
            System.err.println(e);
        }
        System.out.println(receivedData.toString());
        return receivedData.toString();
    }

}